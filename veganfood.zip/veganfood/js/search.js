/**
 * Digital Recipe Book - Real-time Search Engine
 * Refactored & Optimized by Contributor
 */
document.addEventListener("DOMContentLoaded", function () {
    const searchInput = document.getElementById("searchInput");
    const searchForm = document.getElementById("searchForm");
    const recipeItems = document.querySelectorAll(".recipe-item");

    // Card load animation setup
    recipeItems.forEach((card, index) => {
        card.style.animationDelay = ${index * 0.08}s;
    });

    // Handle URL search parameters
    const urlParams = new URLSearchParams(window.location.search);
    const searchQuery = urlParams.get("search");

    if (searchQuery && searchInput) {
        searchInput.value = searchQuery;
        if (recipeItems.length > 0) {
            filterRecipes(searchQuery.toLowerCase().trim());
        }
    }

    // Real-time keyup filtering
    if (searchInput && recipeItems.length > 0) {
        searchInput.addEventListener("keyup", function () {
            const query = searchInput.value.toLowerCase().trim();
            filterRecipes(query);
        });
    }

    function filterRecipes(query) {
        recipeItems.forEach(item => {
            const title = item.querySelector(".card-title") ? item.querySelector(".card-title").textContent.toLowerCase() : "";
            const category = item.getAttribute("data-category") ? item.getAttribute("data-category").toLowerCase() : "";

            if (title.includes(query) || category.includes(query)) {
                item.style.display = "block";
            } else {
                item.style.display = "none";
            }
        });
    }

    // Search form submission validation
    if (searchForm) {
        searchForm.addEventListener("submit", function (e) {
            if (searchInput && searchInput.value.trim() === "") {
                return;
            }

            if (recipeItems.length > 4) {
                e.preventDefault();
            }
        });
    }
});